#ifndef STACK_H
#define STACK_H
#include<QApplication>

class StrStack{

public:
    StrStack(){};
    ~StrStack(){
        while(_size-- != 1)
            this->erase();
        delete _head;
    };

    void push(QChar data);
    QString returnPrev(QChar data);
    QString returnLasts();
    bool fail();

    void erase();
    int powerOfElement(QChar data);

private:

    class Element{
    public:
        Element(QChar data):data(data){};

        Element *elem;
        QChar data;
    };

    int _size = 0;
    Element *_head = nullptr;
};

inline void StrStack::push(QChar data)
{
    if(_size == 0){
        _head = new Element(data);
        _size++;

        return;
    }

    auto tmp = _head;
    _head = new Element(data);
    _head->elem = tmp;

    _size++;

}

inline QString StrStack::returnPrev(QChar data)
{
    if(_size == 0 )
        return "";


    QString str = "";
    while(true){
        if(_size == 0){
            break;
        }
        if( _head->data == '(' && data == ')'){
            this->erase();
            break;
        }
        if(_size != 0 && powerOfElement(_head->data)  >= powerOfElement(data)){

            auto tmp = _head->data;
            this->erase();

            str.push_back(tmp);
        }
        else{
            break;
        }
    }
    return str;
}

inline QString StrStack::returnLasts()
{
    QString str;
    auto tmp = _head;
    for(int i = 0; i < _size; i++){
        if(tmp->data == '(' || tmp->data == ')'){
            tmp = tmp->elem;
            continue;
        }
        str.push_back(tmp->data);
        tmp = tmp->elem;
    }

    return str;
}

inline void StrStack::erase()
{
    if(_size == 0)
        return;

    auto tmp = _head->elem;

    delete _head;
    _head = tmp;

    --_size;
}

inline int StrStack::powerOfElement(QChar data)
{
    if(data == '*' || data == '/' ){
        return 2;
    }
    else if(data == '+' || data == '-' ){
        return 1;
    }
    else if(data == '(' || data == ')'){
        return 0;
    }
    return -1;
}

inline bool StrStack::fail(){
    qDebug() << _head->data;
    if(_head->data == '[' || _head->data == '(' ||_head->data == '{'){
        return false;
    }
    else if(_size == 1){
        return true;
    }
    else{
        if(_head->data == ']' && _head->elem->data == '['){
            erase();
            erase();
            return false;
        }

        if(_head->data == ')' && _head->elem->data == '('){
            erase();
            erase();
            return false;
        }

        if(_head->data == '}' && _head->elem->data == '{'){
            erase();
            erase();
            return false;
        }

        return true;
    }


}


#endif // STACK_H
